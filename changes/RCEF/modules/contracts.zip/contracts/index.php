<?php 
echo "<script>window.location ='http://192.168.1.80/RCEF/' </script>";
?>